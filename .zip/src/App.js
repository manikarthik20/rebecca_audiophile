
import './App.css';
import Rebecca from './components/Rebecca';
import 'bootstrap/dist/css/bootstrap.min.css';
import Footer from './components/Footer';
import Example from './components/Example';

function App() {
  return (
    <div className="App">
     <Rebecca/>
     <Footer/>
    </div>
  );
}

export default App;

// import React from 'react';
// import '../components/Example.css'
// import img from '../images/rebecca.jpg';
// import Footer from './Footer';
// import Rebecca from './Rebecca';

// function Example() {
//   return (
//     <div>
//       <Rebecca/>
//       <Footer/>
//     </div>
//   )
// }

// export default Example
